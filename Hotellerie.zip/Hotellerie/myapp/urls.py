from django.urls import path
from .views import home_view, about_view, login_view, logout_view, home_logged_in_view, register_view
from django.contrib.auth import views as auth_views
from django.contrib import admin
from myapp.views import my_view_function
from .views import MyPasswordResetConfirmView
from . import views
from .views import edit_info

urlpatterns = [
    path('', home_view, name='home'),
    path('about/', about_view, name='about'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('home/', home_logged_in_view, name='home_logged_in'),
     path('register/', register_view, name='register'),
     path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
   path('reset/done/', my_view_function, name='password_reset_complete'),
    path('admin/', admin.site.urls),
      path('password_reset_confirm/<uidb64>/<token>/', MyPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
      path('dashboard/', views.dashboard, name='dashboard'),
      path('edit_info/', edit_info, name='edit_info'),

]
