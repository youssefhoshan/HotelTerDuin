from django.db import models
from django.conf import settings
from django.contrib.auth.views import PasswordResetConfirmView
from django.urls import reverse_lazy


from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, Group, Permission

class Author(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Book(models.Model):
    title = models.CharField(max_length=100)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
    
class MyModel(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

class CustomerUserManager(BaseUserManager):
     def create_user(self, email, password=None, username='default_username', **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, **extra_fields)
        user.set_password(password)
        
        
        user.save()
        return user
    
def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)

class CustomerUser(AbstractBaseUser):
    currency_balance = models.DecimalField(max_digits=19, decimal_places=10, default=0.00)
    email = models.EmailField(unique=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)
    username = models.CharField(max_length=150, unique=True, default="customeruser")
    
    

    groups = models.ManyToManyField(Group, blank=True, related_name='myapp_users')
    user_permissions = models.ManyToManyField(
        Permission,
        blank=True,
        related_name='myapp_users',
        help_text=('Specific permissions for this user.'),
        verbose_name=('user permissions'),
    )
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []
   

   

    objects = CustomerUserManager()
    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True
class CurrencyExchange(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='currency_exchanges')
    currency_to = models.CharField(max_length=3)
    exchange_rate = models.DecimalField(max_digits=19, decimal_places=10)
    amount_from = models.DecimalField(max_digits=19, decimal_places=10)
    amount_to = models.DecimalField(max_digits=19, decimal_places=10)
    currency_from = models.CharField(max_length=50, default=0)
    exchange_rate = models.DecimalField(max_digits=19, decimal_places=10, null=True, blank=True)


    def __str__(self):
        return f"{self.amount_from} {self.currency_from} to {self.amount_to} {self.currency_to} ({self.exchange_rate})"
class MyPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = 'password_reset_confirm.html'
    success_url = reverse_lazy('home')
    extra_context = {'timer': 10}  # Add extra context for timer
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['timer'] = self.extra_context['timer']
        return context