-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2023 at 06:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `base_dir`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add author', 7, 'add_author'),
(26, 'Can change author', 7, 'change_author'),
(27, 'Can delete author', 7, 'delete_author'),
(28, 'Can view author', 7, 'view_author'),
(29, 'Can add book', 8, 'add_book'),
(30, 'Can change book', 8, 'change_book'),
(31, 'Can delete book', 8, 'delete_book'),
(32, 'Can view book', 8, 'view_book'),
(33, 'Can add customer user', 9, 'add_customeruser'),
(34, 'Can change customer user', 9, 'change_customeruser'),
(35, 'Can delete customer user', 9, 'delete_customeruser'),
(36, 'Can view customer user', 9, 'view_customeruser'),
(37, 'Can add my model', 10, 'add_mymodel'),
(38, 'Can change my model', 10, 'change_mymodel'),
(39, 'Can delete my model', 10, 'delete_mymodel'),
(40, 'Can view my model', 10, 'view_mymodel'),
(41, 'Can add currency exchange', 11, 'add_currencyexchange'),
(42, 'Can change currency exchange', 11, 'change_currencyexchange'),
(43, 'Can delete currency exchange', 11, 'delete_currencyexchange'),
(44, 'Can view currency exchange', 11, 'view_currencyexchange');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(3, 'pbkdf2_sha256$600000$zvArMP5guOtoddsXXsLTw3$S3UfnH7vufnAqI83w+niscVBlGY2E6mzKGFEJF6QFo8=', '2023-04-20 10:27:56.500334', 0, 'maniac2', '', '', '', 0, 1, '2023-04-20 10:04:50.148069'),
(4, 'pbkdf2_sha256$600000$MQeixfYxV93zXxFoBGg99e$1w5xZWum/ESa9/FAbFwNG/M3R9ijTFxUp+GVBVRluLU=', '2023-04-20 11:09:16.000000', 0, 'Bukhari', 'Bukhari', '', 'bubu@gmail.com', 0, 1, '2023-04-20 11:09:09.000000'),
(5, 'pbkdf2_sha256$600000$jqpKP6TercoHN5P82lLoVn$sgE1j7vjLMXev86YpPFuqBgP4FtS/D7nxtTaS0UjJT0=', '2023-04-20 16:31:28.288146', 1, 'jean0', '', '', 'jean05@live.nl', 1, 1, '2023-04-20 11:11:29.833598');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2023-04-20 11:13:13.419339', '4', 'Bukhari', 2, '[{\"changed\": {\"fields\": [\"First name\", \"Email address\"]}}]', 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'myapp', 'author'),
(8, 'myapp', 'book'),
(11, 'myapp', 'currencyexchange'),
(9, 'myapp', 'customeruser'),
(10, 'myapp', 'mymodel'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-04-20 00:26:38.804894'),
(2, 'auth', '0001_initial', '2023-04-20 00:26:39.045068'),
(3, 'admin', '0001_initial', '2023-04-20 00:26:39.099712'),
(4, 'admin', '0002_logentry_remove_auto_add', '2023-04-20 00:26:39.106940'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2023-04-20 00:26:39.113123'),
(6, 'contenttypes', '0002_remove_content_type_name', '2023-04-20 00:26:39.145183'),
(7, 'auth', '0002_alter_permission_name_max_length', '2023-04-20 00:26:39.174597'),
(8, 'auth', '0003_alter_user_email_max_length', '2023-04-20 00:26:39.186517'),
(9, 'auth', '0004_alter_user_username_opts', '2023-04-20 00:26:39.193582'),
(10, 'auth', '0005_alter_user_last_login_null', '2023-04-20 00:26:39.212857'),
(11, 'auth', '0006_require_contenttypes_0002', '2023-04-20 00:26:39.215852'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2023-04-20 00:26:39.224069'),
(13, 'auth', '0008_alter_user_username_max_length', '2023-04-20 00:26:39.233716'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2023-04-20 00:26:39.245211'),
(15, 'auth', '0010_alter_group_name_max_length', '2023-04-20 00:26:39.258218'),
(16, 'auth', '0011_update_proxy_permissions', '2023-04-20 00:26:39.264223'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2023-04-20 00:26:39.274713'),
(18, 'sessions', '0001_initial', '2023-04-20 00:26:39.291248'),
(19, 'myapp', '0001_initial', '2023-04-20 00:28:48.786272'),
(20, 'auth', '0013_alter_user_date_joined_alter_user_email_and_more', '2023-04-20 09:51:04.282744'),
(21, 'auth', '0014_alter_user_date_joined_alter_user_email_and_more', '2023-04-20 09:51:04.644776'),
(22, 'myapp', '0002_customeruser_mymodel_currencyexchange', '2023-04-20 09:51:04.815322'),
(23, 'myapp', '0003_auto_20230420_0416', '2023-04-20 09:51:04.818313'),
(24, 'myapp', '0004_alter_customeruser_options_and_more', '2023-04-20 10:02:33.038496'),
(25, 'myapp', '0005_auto_20230420_1202', '2023-04-20 10:03:42.641234'),
(26, 'myapp', '0006_currencyexchange_currency_from', '2023-04-20 10:25:18.538834'),
(27, 'myapp', '0007_merge_20230420_1214', '2023-04-20 10:25:18.543822'),
(28, 'myapp', '0008_currencyexchange_currency_from', '2023-04-20 10:26:25.021001'),
(29, 'myapp', '0009_alter_currencyexchange_exchange_rate', '2023-04-20 10:26:25.062892');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('6h5bktpnuxjtr39puzpz4jvxq8uqrp9g', '.eJxdjs1uwjAQhN_F5zZa_2WbHrnzDNba3iUUGiM7CLWId68jcSnX-eYbzV2FC7V2KzWHyo3XsJYTL-pTxe-fW_19B6t5GoGi2KxdQkb2AoTkE4GxXr2pQNd1DtfGNRxzN1-ySKkvbiB_0XIoQyrLWo9x2CrDk7ZhXzKfd8_uv4GZ2rzZYMVo9A5MxDFbkcnrDyRBk724DhEtpCQSHVD2iRMYNP3yaLQ1k3r8AVBTTRk:1ppXBw:kkp7FKjxJHWnSwR8UqHsmiwpBEvFEOshYqGU5LOroD4', '2023-05-04 16:31:28.289143');

-- --------------------------------------------------------

--
-- Table structure for table `myapp_author`
--

CREATE TABLE `myapp_author` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_book`
--

CREATE TABLE `myapp_book` (
  `id` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `author_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_currencyexchange`
--

CREATE TABLE `myapp_currencyexchange` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `old_currency_from` varchar(255) DEFAULT NULL,
  `currency_to` varchar(3) NOT NULL,
  `rate` decimal(19,10) NOT NULL,
  `amount` decimal(19,10) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp(),
  `first_name` varchar(255) DEFAULT NULL,
  `exchange_rate` decimal(19,10) DEFAULT NULL,
  `amount_from` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_to` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency_from` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_customeruser`
--

CREATE TABLE `myapp_customeruser` (
  `id` bigint(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `currency_balance` decimal(19,10) NOT NULL,
  `username` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_customeruser_groups`
--

CREATE TABLE `myapp_customeruser_groups` (
  `id` bigint(20) NOT NULL,
  `customeruser_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_customeruser_user_permissions`
--

CREATE TABLE `myapp_customeruser_user_permissions` (
  `id` bigint(20) NOT NULL,
  `customeruser_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `myapp_mymodel`
--

CREATE TABLE `myapp_mymodel` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `myapp_author`
--
ALTER TABLE `myapp_author`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `myapp_book`
--
ALTER TABLE `myapp_book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `myapp_book_author_id_bc49495c_fk_myapp_author_id` (`author_id`);

--
-- Indexes for table `myapp_currencyexchange`
--
ALTER TABLE `myapp_currencyexchange`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `myapp_customeruser`
--
ALTER TABLE `myapp_customeruser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `myapp_customeruser_groups`
--
ALTER TABLE `myapp_customeruser_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `myapp_customeruser_groups_customeruser_id_group_id_71b1fe80_uniq` (`customeruser_id`,`group_id`),
  ADD KEY `myapp_customeruser_groups_group_id_a57655ae_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `myapp_customeruser_user_permissions`
--
ALTER TABLE `myapp_customeruser_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `myapp_customeruser_user__customeruser_id_permissi_53db6a78_uniq` (`customeruser_id`,`permission_id`),
  ADD KEY `myapp_customeruser_u_permission_id_2fbc04c0_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `myapp_mymodel`
--
ALTER TABLE `myapp_mymodel`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `myapp_author`
--
ALTER TABLE `myapp_author`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_book`
--
ALTER TABLE `myapp_book`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_currencyexchange`
--
ALTER TABLE `myapp_currencyexchange`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_customeruser`
--
ALTER TABLE `myapp_customeruser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_customeruser_groups`
--
ALTER TABLE `myapp_customeruser_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_customeruser_user_permissions`
--
ALTER TABLE `myapp_customeruser_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myapp_mymodel`
--
ALTER TABLE `myapp_mymodel`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `myapp_book`
--
ALTER TABLE `myapp_book`
  ADD CONSTRAINT `myapp_book_author_id_bc49495c_fk_myapp_author_id` FOREIGN KEY (`author_id`) REFERENCES `myapp_author` (`id`);

--
-- Constraints for table `myapp_currencyexchange`
--
ALTER TABLE `myapp_currencyexchange`
  ADD CONSTRAINT `myapp_currencyexchange_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `myapp_customeruser_groups`
--
ALTER TABLE `myapp_customeruser_groups`
  ADD CONSTRAINT `myapp_customeruser_g_customeruser_id_69ad7190_fk_myapp_cus` FOREIGN KEY (`customeruser_id`) REFERENCES `myapp_customeruser` (`id`),
  ADD CONSTRAINT `myapp_customeruser_groups_group_id_a57655ae_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `myapp_customeruser_user_permissions`
--
ALTER TABLE `myapp_customeruser_user_permissions`
  ADD CONSTRAINT `myapp_customeruser_u_customeruser_id_39311db5_fk_myapp_cus` FOREIGN KEY (`customeruser_id`) REFERENCES `myapp_customeruser` (`id`),
  ADD CONSTRAINT `myapp_customeruser_u_permission_id_2fbc04c0_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
